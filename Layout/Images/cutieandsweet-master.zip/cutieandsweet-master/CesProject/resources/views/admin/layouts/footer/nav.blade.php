<footer class="footer">
    <div class="container @auth-fluid @endauth">
        <nav>
            <p class="copyright text-center">
                ©
                <script>
                    document.write(new Date().getFullYear())
                </script>
                <a disabled >{{ __('Cutie & Sweet - Moda Fashion') }}</a>
            </p>
        </nav>
    </div>
</footer>