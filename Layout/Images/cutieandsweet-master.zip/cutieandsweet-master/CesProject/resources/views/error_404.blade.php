@extends('layouts/app', ['activePage' => 'sobre', 'title' => 'Sobre a C&S - Cutie & Sweet'])

@section('content')
    <div class="div-error">
        <h2>ERRO 404</h2>
        <h3>Página Não Encontrada</h3>
    </div>
@endsection